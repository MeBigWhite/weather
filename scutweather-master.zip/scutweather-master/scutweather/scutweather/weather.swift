//
//  weather.swift
//  scutweather
//
//  Created by 最后一排的 on 2019/11/19.
//  Copyright © 2019 scut_flyc. All rights reserved.
//

import Foundation
class weather{
    var temperature: String
    var weather: String
    
    init(temperature: String,weather: String){
        self.temperature = temperature
        self.weather = weather
    }
}
